<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?=base_url?>assets/css/styles.css">
</head>

<body>

<div class="container">
    <div class="container-texto">
    <h1 class="titulo">Aplicación para crear tus tareas</h1>
    <div class="header">
        <ul>
            <li><a href="<?= base_url ?>Task/crear">Crear Tarea</a></li>
            <li><a href="<?= base_url ?>">HOME</a></li>     
        </ul>

    </div>

