
<h1>Tarea completada</h1>
<?php
header("refresh: 1; url=" . base_url);