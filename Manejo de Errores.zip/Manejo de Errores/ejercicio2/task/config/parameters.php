<?php
define("base_url", "http://localhost/manejoErrores/manejoErrores/ejercicio2/task/HOME");
define("controller_default","taskController");
define("action_default","listTask");