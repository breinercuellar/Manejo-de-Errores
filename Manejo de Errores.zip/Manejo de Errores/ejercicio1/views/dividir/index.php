<form action="<?=base_url?>dividir/guardar" method="post">
    <label for="dividendo">Ingrese el dividendo</label>
    <input type="text" name="dividendo" >

    <label for="divisor">Ingrese el divisor</label>
    <input type="text" name="divisor">

    <button type="submit">Dividir</button>
</form>