<?php

class DefaultController{
    public function index()
    {
        require_once "views/default/index.php";
    }
}